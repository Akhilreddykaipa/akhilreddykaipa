package com.bankProject.dao.serviceImpl;

import com.bankProject.dao.BalanceDao;
import com.bankProject.dao.repository.BalanceDetailsRepository;
import com.bankProject.model.Balance;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class BalanceDetailsServiceImpl implements BalanceDao {

    @Autowired
    private BalanceDetailsRepository balanceDetailsRepository;
    @Override
    public Balance getBalanceDetails(String AccountNo) {
        return balanceDetailsRepository.findById(AccountNo).orElse(null);
    }

    public Balance saveBalamceDetails(Balance balance){
        return balanceDetailsRepository.saveAndFlush(balance);
    }
}
