package com.bankProject.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "Balance", schema = "myapp")
public class Balance {
    @Id
    String bankNameAccNo;
    String accountNumber;
    String accountBalance;
    String accCurrency;
    Boolean isAccActive;
    String accType;
    Boolean isAccJoint;
    String bankName;
}
