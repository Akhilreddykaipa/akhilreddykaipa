package com.bankProject.dao.repository;

import com.bankProject.model.Banking_Frontend;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface FrontEndRepository extends JpaRepository<Banking_Frontend, String> {

}
