package com.bankProject.dao;

import com.bankProject.model.Account;

public interface AccountDao {
    Account getAccountDetails(String accountNo);
}
