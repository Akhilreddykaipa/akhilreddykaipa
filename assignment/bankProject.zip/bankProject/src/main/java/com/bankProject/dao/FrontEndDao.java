package com.bankProject.dao;
import com.bankProject.model.Banking_Frontend;

import java.util.List;
import java.util.Optional;

public interface FrontEndDao {

    Banking_Frontend getFrontEndFieldId(String frontEndFieldId);

}
