package com.bankProject.dao;

import com.bankProject.model.Balance;
import com.bankProject.model.Banking_Frontend;

public interface BalanceDao {
    Balance getBalanceDetails(String AccountNo);
}
