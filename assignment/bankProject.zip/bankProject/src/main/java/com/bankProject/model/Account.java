package com.bankProject.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "Account", schema = "myapp")
public class Account {
    @Id
    String accountNumber;
    String customerName;
    String customerAddress;
    String customerMobNo;
    String bankName;
    String accOpeningDate;
    String coApplicantName;
}
