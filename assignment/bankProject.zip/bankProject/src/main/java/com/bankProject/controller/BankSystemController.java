package com.bankProject.controller;


import com.bankProject.dao.serviceImpl.AccountDetailsServiceImpl;
import com.bankProject.dao.serviceImpl.BalanceDetailsServiceImpl;
import com.bankProject.dao.serviceImpl.FrontEndServiceImpl;
import com.bankProject.model.Account;
import com.bankProject.model.Balance;
import com.bankProject.model.Banking_Frontend;
import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.Unirest;
import com.mashape.unirest.http.exceptions.UnirestException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.Scanner;


@Controller
public class BankSystemController {
    @Autowired
    private FrontEndServiceImpl frontEndService;
    @Autowired
    private AccountDetailsServiceImpl accountDetailsService;
    @Autowired
    private BalanceDetailsServiceImpl balanceDetailsService;

    @RequestMapping("/home")
    public void mainPage() throws UnirestException {

       // List<Banking_Frontend> banking_frontendList = frontEndService.getAllFields();
        Banking_Frontend banking_frontend = getBnkingFrontEnd("dropdown");
        //System.out.println(banking_frontend.getFieldSize());
        String [] bankArr = banking_frontend.getFieldData().split(",");
        List<String> field_Id = Arrays.asList(bankArr);
        displayMenu(field_Id);
       // return "main";
    }

    private void displayMenu(List<String> field_id) throws UnirestException {
        System.out.println(" Welcome to Banking System ");
        System.out.println(" Please Select Bank ... ");
        int counter = 1;
        for (String fieldVal : field_id)
            System.out.println(counter+++". "+fieldVal);
        getSeletionFromUser(field_id);
    }

    private Banking_Frontend getBnkingFrontEnd(@PathVariable String field_Id){
        return frontEndService.getFrontEndFieldId(field_Id);
    }

    private Account getAccDetails(@PathVariable String accountNo){
        return accountDetailsService.getAccountDetails(accountNo);
    }
    private Balance getBalanceDetails(@PathVariable String accountNoBankName){
        return balanceDetailsService.getBalanceDetails(accountNoBankName);
    }

    public void callMainService() throws UnirestException {
        Unirest.setTimeouts(0, 0);
        HttpResponse<String> response = Unirest.get("http://localhost:8087/home")
                .asString();

    }

    public void getSeletionFromUser(List<String> field_id) throws UnirestException {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter Your Bank Name : ");
        String bankName = scanner.next();
        System.out.println(bankName);
        userSelection(bankName,field_id,scanner);

    }

    private void userSelection(String bankName, List<String> field_id, Scanner scanner) throws UnirestException {
        boolean x = false;
        int valIndex = Integer.parseInt(bankName);
        if(valIndex <= 0 || valIndex > field_id.size()){
            System.out.println("Please Re-Enter Correct Bank Name Which is in List - ");
            getSeletionFromUser(field_id);
        }
        while (true) {
            if (field_id.stream().anyMatch(a->a.contains(field_id.get(0)))) {
                checkBankUser(field_id,valIndex-1,scanner);
                break;
            }else{
                System.out.println("Please Re-Enter Correct Bank Name Which is in List - ");
                getSeletionFromUser(field_id);
            }
        }
    }

    private void checkBankUser(List<String> field_id, int listIndex, Scanner scanner) throws UnirestException {

        System.out.println("Welcome to "+ field_id.get(listIndex)+".");
        System.out.println("Please Enter Your Choice So we can Proceed further ... "+
                "\n1. Existing Account Holder In "+ field_id.get(listIndex)+"."+
                "\n2. Want to create new Account with "+ field_id.get(listIndex)+"."+
                        "\n3. Again want to select bank name ...");
        String userChoice = scanner.next();
        if(userChoice.equals("1")){
            showMenuForExistingAccountHolder(field_id.get(listIndex),scanner);

        }else if (userChoice.equals("2")){
            createNewAccount(field_id.get(listIndex),scanner);

        } else if (userChoice.equals("3")) {
            displayMenu(field_id);
        } else{
            System.out.println("Ohh! You enterd wrongly Please try again...");
            checkBankUser(field_id,listIndex,scanner);
        }

    }

    private void createNewAccount(String bankName, Scanner scanner) throws UnirestException {
        System.out.println("We appreciate your choice..." +
                "\nFew steps away from New Account creation with " +bankName+
                "\nDo you want to create single Account holder or Joint Account holder Account" +
                "\nIf yes then please type Y/y, If not then please type N/n : " );
        Boolean jointType = Boolean.FALSE;
        String userVal = scanner.next();
        String bankNameInput = bankName;
        System.out.println(userVal);


        if(userVal.equalsIgnoreCase("Y")){
            jointType = Boolean.TRUE;
            createAccSaveDetails(jointType,scanner,bankName);

        } else if (userVal.equalsIgnoreCase("N")) {
            jointType = Boolean.FALSE;
            createAccSaveDetails(jointType,scanner,bankName);
        }


    }

    private void createAccSaveDetails(Boolean jointType, Scanner scanner, String bankName) throws UnirestException {
        Account account = new Account();
        Balance balance = new Balance();
        balance.setIsAccJoint(jointType);
        balance.setAccountBalance("5");
        balance.setAccCurrency("INR");
        System.out.println("Enter Your Full Name :");
        account.setCustomerName(scanner.next());
        String co_ApplicantName = "";
        if(jointType.equals(Boolean.TRUE)){
            System.out.println("Enter Your Full Name :");
            co_ApplicantName = scanner.next();
            account.setCoApplicantName(co_ApplicantName);
        }
        System.out.println("Enter Adress ");
        account.setCustomerAddress(scanner.next());
        account.setAccOpeningDate(String.valueOf(java.time.ZonedDateTime.now()));
        String accNo = String.valueOf(accountNumberGenerator(0,10000000000L));
        account.setAccountNumber(accNo);
        balance.setAccountNumber(accNo);
        account.setBankName(bankName);
        balance.setBankName(bankName);
        balance.setBankNameAccNo(bankName+"-"+accNo);
        accountDetailsService.saveDetails(account);
        balanceDetailsService.saveBalamceDetails(balance);
        System.out.println("Your Account Creation is done Your Account no is " + accNo);
        System.out.println("Do you want to Continue.." +
                "\n 1. Yes" +
                "\n 2. No");
        String userIn = scanner.next();
        if(userIn.equalsIgnoreCase("1")){
            callMainService();
        }else{
            System.exit(0);
        }
    }

    private long accountNumberGenerator(int aStart, long aEnd) {
        Random random = new Random();
        if ( aStart > aEnd ) {
            throw new IllegalArgumentException("Start cannot exceed End.");
        }
        //get the range, casting to long to avoid overflow problems
        long range = aEnd - (long)aStart + 1;
        System.out.println("range>>>>>>>>>>>"+range);
        // compute a fraction of the range, 0 <= frac < range
        long fraction = (long)(range * random.nextDouble());
        System.out.println("fraction>>>>>>>>>>>>>>>>>>>>"+fraction);
        long randomNumber =  fraction + (long)aStart;
        System.out.println("Generated : " + randomNumber);
        return randomNumber;
    }

    private void showMenuForExistingAccountHolder(String bankName, Scanner scanner) {
        System.out.println("Welcome In "+bankName);
        System.out.println("\n1. Check Account Balance." +
                "\n2. Withdraw Money From Account.");
        String userInput = scanner.next();
        checkBalance(userInput,scanner,bankName);
    }

    private void checkBalance(String userInput, Scanner scanner, String bankName) {
        System.out.println("Enter Your Account No ");
        String accNo = scanner.next();
        Balance balance = getBalanceDetails(bankName+"-"+accNo);
        System.out.println("Your Accounting is holding "+ balance.getAccountBalance() +" amount");
    }
}
