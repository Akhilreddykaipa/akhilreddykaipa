package com.bankProject.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "banking_frontend", schema = "myapp")
public class Banking_Frontend {

    @Id
    @Column(name = "field_Id")
    private String field_Id;
    private String fieldData;
    private String fieldSize;

}
