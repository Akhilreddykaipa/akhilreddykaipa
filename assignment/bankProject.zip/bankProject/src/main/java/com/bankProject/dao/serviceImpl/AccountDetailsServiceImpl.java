package com.bankProject.dao.serviceImpl;

import com.bankProject.dao.AccountDao;
import com.bankProject.dao.repository.AccountDetailsRepository;
import com.bankProject.model.Account;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AccountDetailsServiceImpl implements AccountDao {

    @Autowired
    private AccountDetailsRepository accountDetailsRepository;

    @Override
    public Account getAccountDetails(String accountNo) {
        return accountDetailsRepository.findById(accountNo).orElse(null);
    }

    public Account saveDetails(Account account){
        return accountDetailsRepository.saveAndFlush(account);
    }

}
