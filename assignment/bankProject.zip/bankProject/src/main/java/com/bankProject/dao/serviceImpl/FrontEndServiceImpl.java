package com.bankProject.dao.serviceImpl;

import com.bankProject.dao.FrontEndDao;
import com.bankProject.dao.repository.FrontEndRepository;
import com.bankProject.model.Banking_Frontend;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
@Service
public class FrontEndServiceImpl implements FrontEndDao {

    @Autowired
    private FrontEndRepository frontEndRepository;
    @Override
    public Banking_Frontend getFrontEndFieldId(String field_Id) {
       return frontEndRepository.findById(field_Id).orElse(null);
    }


}
