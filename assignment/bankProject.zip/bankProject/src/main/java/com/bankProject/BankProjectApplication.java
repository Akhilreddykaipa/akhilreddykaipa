package com.bankProject;

import com.bankProject.controller.BankSystemController;
import com.mashape.unirest.http.exceptions.UnirestException;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BankProjectApplication {

	public static void main(String[] args) throws UnirestException {
		SpringApplication.run(BankProjectApplication.class, args);
		BankSystemController bankSystemController = new BankSystemController();
		bankSystemController.callMainService();
	}



}
