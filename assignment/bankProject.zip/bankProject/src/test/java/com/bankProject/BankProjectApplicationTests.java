package com.bankProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
